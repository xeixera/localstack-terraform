import boto3, os


dynamodb = boto3.resource("dynamodb")

TABLE_NAME = os.environ["DYNAMODB_TABLE"]
print(f"DYNAMODB_TABLE = {TABLE_NAME}")

table = dynamodb.Table(TABLE_NAME)

def lambda_handler(event, context):

    print(f"its working:{event}")

    for record in event["Records"]:

        message_id = record["messageId"]
        mensagem = record["body"]

        table.put_item(
            Item={
                "id": message_id,
                "mensagem": mensagem
            }
        )

        print(f"message send to dynamodb: {message_id}")

    return {
        "statusCode": 200,
        "body": "i really like this! nicee!"
    }